public class Hammer extends WorkTool {
    void use(){
        System.out.println("Uzylem mlota");
    }
}
