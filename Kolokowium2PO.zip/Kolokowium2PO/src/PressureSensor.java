public class PressureSensor implements Sensor{
    public double readValue(){
        return 3.4;
    }
    public String getStatus(){
        return "Status is: ...";
    }
    public void reset(){
        System.out.println("Reset!");
    }
}
