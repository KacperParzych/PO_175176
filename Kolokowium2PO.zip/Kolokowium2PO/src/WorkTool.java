public abstract class WorkTool {
    String name;
    int productionYear;
    abstract void use();

}
