public class TemperatureSensor implements Sensor{
    public double readValue(){
        return 1.0;
    }
    public String getStatus(){
        return "Status is:";
    }
    public void reset(){
        System.out.println("Reset!");
    }
}
