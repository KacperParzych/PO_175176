public class Screwdriver extends WorkTool{
    void use(){
        System.out.println("Uzyles screwdriver");
    }

}
