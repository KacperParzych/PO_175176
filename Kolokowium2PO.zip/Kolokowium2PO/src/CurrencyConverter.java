public class CurrencyConverter implements Converter{

    @Override
    public double convertToEuro(double amount) {
        return 0;
    }

    @Override
    public double convertToUSD(double amount) {
        return 0;
    }

    @Override
    public double getConversionRate(String currency) {
        return 0;
    }
}
