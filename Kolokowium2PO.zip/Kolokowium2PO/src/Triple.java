public class Triple <T>{
    T a;
    T b;
    T c;

    public Triple(T a, T b, T c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    T getFirst(T a){
        return a;
    }

    T getSecond(T b){
        return b;
    }

    T getThird(T c){
        return c;
    }
}
