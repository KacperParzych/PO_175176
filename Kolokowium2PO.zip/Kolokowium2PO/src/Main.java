
public class Main {
    <T> boolean isEqualOrNull(T a, T b){
        if(a.equals(b)){
            return true;
        } else if (a==null && b == null) {
            return true;
        } else{
            return false;
        }
    }
    public static void main(String[] args) {
    }
}